# Contributors


### Core Team

- Josh Goebel <hello@joshgoebel.com> (maintainer)
- Egor Rogov <e.rogov@postgrespro.ru>
- Vladimir Jimenez <me@allejo.io>

### Former Maintainers

- Ivan Sagalaev <maniac@softwaremaniacs.org> (original author)
- Jeremy Hull <sourdrums@gmail.com>
- Oleg Efimov <efimovov@gmail.com>

### Former Core Team

- Gidi Meir Morris <gidi@gidi.io>
- Jan T. Sott <git@idleberg.com>
- Li Xuanji <xuanji@gmail.com>
- Marcos Cáceres <marcos@marcosc.com>
- Sang Dang <sang.dang@polku.io>


### Individual Contributors

Highlight.js has also been greatly improved over the years thanks to the help of [many other contributors](https://github.com/highlightjs/highlight.js/graphs/contributors).  A big thank you to everyone who has helped make this project what it is today!
